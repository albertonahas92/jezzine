/**
 * Default theme functions
 */
$(document).ready(function() {

});
