var elem = document.querySelector('.dropdown-trigger');
var instance = M.Dropdown.init(elem, options);

// Or with jQuery

$('.dropdown-trigger').dropdown();