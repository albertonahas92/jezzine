<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="heading"></div>
<div style="text-align:center;margin:3em;" class="row">
    <div class="col-lg-12">
        <h2 class="text-center"><?php echo lang('core text oops'); ?></h2>
        <p class="text-center"><?php echo lang('core text 404_error'); ?></p>
        <pre class="error-404">
  
        </pre>
        <p class="text-center">
            <a type="button" class="btn btn-primary btn-lg" href="<?php echo base_url(); ?>"><?php echo lang('core button return_home'); ?></a>
        </p>
    </div>
</div>
