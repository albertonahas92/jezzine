<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<p><?php echo lang('admin dashboard text welcome'); ?></p>

<br />
<button id="jsi18n-sample" type="button" class="btn btn-primary"><?php echo lang('admin dashboard btn demo'); ?></button>
