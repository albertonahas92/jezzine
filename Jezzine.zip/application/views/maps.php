<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="heading"></div>
<iframe
 width="100%" height="600"
  frameborder="0" style="border:0"
  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBd8QfarL-Hx3vD4JTKeJN4xMY02GtJJik
    &q=Lebanon+Jezzine" allowfullscreen>
</iframe>
    <!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
    
 