<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 */

// Titles
$lang['admin settings title']             = "Настройки";

// Messages
$lang['admin settings msg save_success']  = "Настройки были успешно сохранены.";

// Errors
$lang['admin settings error save_failed'] = "Во время сохнанения настроек возникли проблемы. Повторите снова.";
