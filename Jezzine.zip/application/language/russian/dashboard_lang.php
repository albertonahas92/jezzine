<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Dashboard Language File
 */

// Text
$lang['admin dashboard text welcome']  = "Добро пожаловать в Панель управления!";

// Buttons
$lang['admin dashboard btn demo']      = "Нажмите для демонстрации JS-интернационализации (Jsi18n)";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "Это демонстрация работы библиотеки Jsi18n. Она берёт текст из языкового файла и вставляет в ваш Javascripts. Смотрите файлы jsi18n.php и dashboard_i18n.js.";
