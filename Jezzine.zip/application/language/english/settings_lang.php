<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 */

// Titles
$lang['admin settings title']             = "Settings";

// Messages
$lang['admin settings msg save_success']  = "Settings have been successfully saved.";

// Errors
$lang['admin settings error save_failed'] = "There was a problem saving settings. Please try again.";
