<?php	defined('BASEPATH') OR exit('Akses skrip secara langsung tidak diijinkan');
/**
 * File Bahasa Indoensia - Dashboard
 */

// Text
$lang['admin dashboard text welcome']  = "Halo dan Selamat datang dashboard !";

// Buttons
$lang['admin dashboard btn demo']      = "Klik untuk Jsi18n Demo";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "Ini merupakan demo penggunaan librari Jsi18n. Librari ini mengambil teks dari file bahasa dan memasukkannya ke dalam Javascripts anda. Lihatlah file jsi18n.php library dan dashboard_i18n.js untuk penggunaannya.";
