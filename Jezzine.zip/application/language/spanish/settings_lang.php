<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 */

// Titles
$lang['admin settings title']             = "Ajustes";

// Messages
$lang['admin settings msg save_success']  = "Configuración se ha guardado correctamente.";

// Errors
$lang['admin settings error save_failed'] = "Hubo un problema al guardar la configuración. Por favor, vuelva a intentarlo.";
