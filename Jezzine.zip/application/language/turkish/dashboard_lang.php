<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Dashboard Language File
 */

// Text
$lang['admin dashboard text welcome']  = "Merhaba ve pano hoş geldiniz!";

// Buttons
$lang['admin dashboard btn demo']      = "Jsi18n Demo için tıklayınız";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "Bu Jsi18n kütüphane bir örneğidir. Bu dosya dili metin alır ve sizin Javascripts ekler. Jsi18n.php Kütüphane ve kullanım için dashboard_i18n.js bakın.";
