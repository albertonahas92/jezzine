<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 */

// Titles
$lang['admin settings title']             = "Ayarlar";

// Messages
$lang['admin settings msg save_success']  = "Ayarları başarıyla kaydedildi.";

// Errors
$lang['admin settings error save_failed'] = "Ayarlarını kaydederken bir hata oluştu. Lütfen yeniden deneyin.";
