<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Dashboard Language File
 * author Evenvi
 * www.evenvi.com
 */

// Text
$lang['admin dashboard text welcome']  = "您好，欢迎到仪表板!";

// Buttons
$lang['admin dashboard btn demo']      = "点击Jsi18n演示";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "这是Jsi18n库​​的演示. 它需要文本从一种语言文件，并将其插入到你的Javascript. 见jsi18n.php库和dashboard_i18n.js的使用.";
